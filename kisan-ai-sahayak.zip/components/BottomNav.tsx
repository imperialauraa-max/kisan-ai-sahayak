
import React from 'react';
// FIX: Import Language to use for prop typing
import { Page, Language } from '../types';
import { I18N } from '../constants';

interface BottomNavProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  // FIX: The language prop should be of type Language, not derived from the LANGUAGES array keys.
  language: Language;
}

const HomeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
const CloudIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" /></svg>;
const ChartBarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
const BeakerIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547a2 2 0 00-.547 1.806l.477 2.387a6 6 0 00.517 3.86l.158.318a6 6 0 00.517 3.86l2.387.477a2 2 0 001.806.547a2 2 0 00.547-1.806l-.477-2.387a6 6 0 00-.517-3.86l-.158-.318a6 6 0 00-.517-3.86l-2.387-.477zM11.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L-.05 15.21a2 2 0 00-1.806.547a2 2 0 00-.547 1.806l.477 2.387a6 6 0 00.517 3.86l.158.318a6 6 0 00.517 3.86l2.387.477a2 2 0 001.806.547a2 2 0 00.547-1.806l-.477-2.387a6 6 0 00-.517-3.86l-.158-.318a6 6 0 00-.517-3.86l-2.387-.477z" /></svg>;
const UserCircleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;


const ICONS: Record<Page, React.FC> = {
  [Page.Home]: HomeIcon,
  [Page.Weather]: CloudIcon,
  [Page.Prices]: ChartBarIcon,
  [Page.Advice]: BeakerIcon,
  [Page.Profile]: UserCircleIcon,
};

// FIX: Use Language.en to correctly reference the english translations object type from I18N.
const PAGE_TRANSLATIONS: Record<Page, keyof typeof I18N[Language.en]> = {
  [Page.Home]: 'home',
  [Page.Weather]: 'weather',
  [Page.Prices]: 'prices',
  [Page.Advice]: 'advice',
  [Page.Profile]: 'profile',
}


const BottomNav: React.FC<BottomNavProps> = ({ currentPage, setCurrentPage, language }) => {
  const t = I18N[language];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-green-200 shadow-lg z-50">
      <div className="flex justify-around max-w-lg mx-auto">
        {(Object.keys(Page) as Array<keyof typeof Page>).map((key) => {
          const page = Page[key];
          const isActive = currentPage === page;
          const Icon = ICONS[page];
          const translationKey = PAGE_TRANSLATIONS[page];
          return (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              className={`flex flex-col items-center justify-center w-full pt-2 pb-1 text-sm transition-colors duration-200 ${
                isActive ? 'text-green-600' : 'text-gray-500 hover:text-green-500'
              }`}
            >
              <Icon />
              <span className={`mt-1 font-medium ${isActive ? 'font-bold' : ''}`}>
                {t[translationKey]}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
