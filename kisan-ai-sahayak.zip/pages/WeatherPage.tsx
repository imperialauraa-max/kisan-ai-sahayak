import React, { useState, useEffect } from 'react';
import { getWeatherData } from '../services/weatherService';
import { WeatherData, ForecastData, Language } from '../types';
import { I18N, LANGUAGES } from '../constants';

interface WeatherPageProps {
  language: Language;
}

const WeatherCard: React.FC<{ weather: WeatherData }> = ({ weather }) => (
  <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg text-center text-green-900 w-full max-w-sm">
    <p className="text-xl font-semibold">{weather.city}</p>
    <div className="flex items-center justify-center my-4">
      <span className="text-7xl">{weather.icon}</span>
      <div className="ml-4 text-left">
        <p className="text-6xl font-bold">{weather.temperature}°C</p>
        <p className="text-lg capitalize">{weather.condition}</p>
      </div>
    </div>
    <div className="flex justify-around text-sm">
      <div>
        <p className="font-bold">{weather.humidity}%</p>
        <p>Humidity</p>
      </div>
      <div>
        <p className="font-bold">{weather.windSpeed} km/h</p>
        <p>Wind Speed</p>
      </div>
    </div>
  </div>
);

const ForecastItem: React.FC<{ item: ForecastData }> = ({ item }) => (
  <div className="flex flex-col items-center justify-center bg-white/70 backdrop-blur-sm p-3 rounded-xl shadow-md flex-1 min-w-[70px]">
    <p className="font-bold text-lg text-green-800">{item.day}</p>
    <span className="text-3xl my-1">{item.icon}</span>
    <p className="text-sm text-green-900">{item.temp_max}°/{item.temp_min}°</p>
  </div>
);

const WeatherPage: React.FC<WeatherPageProps> = ({ language }) => {
  const t = I18N[language];
  const [weather, setWeather] = useState<WeatherData | null>(JSON.parse(localStorage.getItem('weather') || 'null'));
  const [forecast, setForecast] = useState<ForecastData[]>(JSON.parse(localStorage.getItem('forecast') || '[]'));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchWeather = () => {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            setError(null);
            setLoading(true);
            const data = await getWeatherData(position.coords.latitude, position.coords.longitude);
            setWeather(data.current);
            setForecast(data.forecast);
            localStorage.setItem('weather', JSON.stringify(data.current));
            localStorage.setItem('forecast', JSON.stringify(data.forecast));
          } catch (err) {
            setError("Failed to fetch weather data.");
          } finally {
            setLoading(false);
          }
        },
        (geoError) => {
          setError("Geolocation permission denied. Please enable it in your browser settings.");
          setLoading(false);
        }
      );
    };

    fetchWeather();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="p-4 bg-gradient-to-b from-green-200 to-lime-100 min-h-full">
      {loading && <p className="text-center text-green-700">Loading weather data...</p>}
      {error && <p className="text-center text-red-600 bg-red-100 p-3 rounded-lg">{error}</p>}
      {!loading && weather && (
        <div className="flex flex-col items-center gap-6">
          <h2 className="text-2xl font-bold text-green-800">{t.currentWeather}</h2>
          <WeatherCard weather={weather} />
          
          <h2 className="text-2xl font-bold text-green-800 mt-4">{t.forecast}</h2>
          <div className="flex gap-2 sm:gap-4 w-full max-w-sm justify-between">
            {forecast.map((item) => (
              <ForecastItem key={item.day} item={item} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default WeatherPage;