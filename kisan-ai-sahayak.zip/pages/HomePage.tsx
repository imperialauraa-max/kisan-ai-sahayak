import React, { useState, useRef, useCallback, useEffect } from 'react';
import { I18N, LANGUAGES } from '../constants';
import { LiveServerMessage, LiveSession, Blob as GenAiBlob } from '@google/genai';
import { connectLive } from '../services/geminiService';
import { encode, decode, decodeAudioData } from '../utils/audioUtils';
import { Language } from '../types';

interface HomePageProps {
  language: Language;
}

const MicIcon = ({ isListening }: { isListening: boolean }) => (
  <svg className={`h-16 w-16 transition-transform duration-200 ${isListening ? 'scale-110' : ''}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3z"></path>
    <path d="M12 17.3c-2.4 0-4.3-1.9-4.3-4.3H6c0 3.3 2.7 6 6 6s6-2.7 6-6h-1.7c0 2.4-1.9 4.3-4.3 4.3z"></path>
    <path d="M12 2a1 1 0 011 1v2.1a7 7 0 010 13.8V21a1 1 0 01-2 0v-2.1a7 7 0 010-13.8V3a1 1 0 011-1z"></path>
  </svg>
);

const HomePage: React.FC<HomePageProps> = ({ language }) => {
  const t = I18N[language];
  
  const [sessionStatus, setSessionStatus] = useState<'idle' | 'connecting' | 'connected' | 'error' | 'disconnected'>('idle');
  const [transcriptions, setTranscriptions] = useState<{user?: string, model?: string}[]>([]);
  const [currentTranscription, setCurrentTranscription] = useState<{user: string, model: string}>({user: '', model: ''});
  
  const sessionPromiseRef = useRef<Promise<LiveSession> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const handleDisconnect = useCallback(() => {
    if(sessionPromiseRef.current){
      sessionPromiseRef.current.then(session => session.close());
    }
    
    streamRef.current?.getTracks().forEach(track => track.stop());
    scriptProcessorRef.current?.disconnect();
    mediaStreamSourceRef.current?.disconnect();
    audioContextRef.current?.close();

    audioSourcesRef.current.forEach(source => source.stop());
    outputAudioContextRef.current?.close();

    sessionPromiseRef.current = null;
    streamRef.current = null;
    audioContextRef.current = null;
    scriptProcessorRef.current = null;
    mediaStreamSourceRef.current = null;
    outputAudioContextRef.current = null;
    nextStartTimeRef.current = 0;
    audioSourcesRef.current.clear();

    setSessionStatus('disconnected');
    setCurrentTranscription({user: '', model: ''});
  }, []);

  const handleConnect = useCallback(async () => {
    setSessionStatus('connecting');
    setTranscriptions([]);
    setCurrentTranscription({user: '', model: ''});

    try {
      streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });

      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const outputNode = outputAudioContextRef.current.createGain();
      outputNode.connect(outputAudioContextRef.current.destination);

      const callbacks = {
        onopen: () => {
          setSessionStatus('connected');
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
          mediaStreamSourceRef.current = audioContextRef.current.createMediaStreamSource(streamRef.current!);
          scriptProcessorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);
          
          scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
            const l = inputData.length;
            const int16 = new Int16Array(l);
            for (let i = 0; i < l; i++) {
              int16[i] = inputData[i] * 32768;
            }
            const pcmBlob: GenAiBlob = {
              data: encode(new Uint8Array(int16.buffer)),
              mimeType: 'audio/pcm;rate=16000',
            };
            if(sessionPromiseRef.current) {
                sessionPromiseRef.current.then((session) => {
                    session.sendRealtimeInput({ media: pcmBlob });
                });
            }
          };

          mediaStreamSourceRef.current.connect(scriptProcessorRef.current);
          scriptProcessorRef.current.connect(audioContextRef.current.destination);
        },
        onmessage: async (message: LiveServerMessage) => {
          if(message.serverContent?.inputTranscription) {
            setCurrentTranscription(prev => ({...prev, user: prev.user + message.serverContent!.inputTranscription!.text}));
          }
          if(message.serverContent?.outputTranscription) {
            setCurrentTranscription(prev => ({...prev, model: prev.model + message.serverContent!.outputTranscription!.text}));
          }
          if(message.serverContent?.turnComplete) {
            setTranscriptions(prev => [...prev, currentTranscription]);
            setCurrentTranscription({user: '', model: ''});
          }

          const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (base64Audio && outputAudioContextRef.current) {
              const audioCtx = outputAudioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioCtx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), audioCtx, 24000, 1);
              const source = audioCtx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputNode);
              source.addEventListener('ended', () => {
                audioSourcesRef.current.delete(source);
              });

              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              audioSourcesRef.current.add(source);
          }
        },
        onerror: (e: ErrorEvent) => {
          console.error('Live session error:', e);
          setSessionStatus('error');
          handleDisconnect();
        },
        onclose: (e: CloseEvent) => {
          handleDisconnect();
        },
      };

      sessionPromiseRef.current = connectLive(callbacks);

    } catch (err) {
      console.error('Failed to get user media', err);
      setSessionStatus('error');
    }
  }, [handleDisconnect, currentTranscription]);
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
        handleDisconnect();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const isListening = sessionStatus === 'connected';

  return (
    <div className="flex flex-col h-full items-center justify-between text-center p-4 bg-lime-50 text-green-900">
      <div className="w-full">
        <h1 className="text-4xl font-bold text-green-700">{t.welcome}</h1>
        <p className="text-lg mt-2 text-green-600">{t.tagline}</p>
      </div>

      <div className="flex-grow flex flex-col justify-center items-center w-full my-4">
        <button
          onClick={isListening ? handleDisconnect : handleConnect}
          disabled={sessionStatus === 'connecting'}
          className={`relative rounded-full transition-all duration-300 ease-in-out shadow-lg flex items-center justify-center
            ${isListening ? 'w-48 h-48 bg-red-500 hover:bg-red-600 text-white' : 'w-40 h-40 bg-green-500 hover:bg-green-600 text-white'}
            ${sessionStatus === 'connecting' ? 'w-40 h-40 bg-yellow-500 cursor-not-allowed' : ''}`}
        >
          {sessionStatus !== 'connecting' && <MicIcon isListening={isListening} />}
          {isListening && (
            <div className="absolute w-full h-full border-4 border-green-300 rounded-full animate-ping"></div>
          )}
          {sessionStatus === 'connecting' && <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-white"></div>}
        </button>
        <p className="mt-6 text-xl font-medium text-green-800">
          {sessionStatus === 'idle' || sessionStatus === 'disconnected' ? t.speakNow :
           sessionStatus === 'connecting' ? t.connecting :
           isListening ? t.listening : ''}
        </p>

        <div className="mt-4 w-full max-w-lg h-48 bg-white rounded-lg shadow-inner p-4 overflow-y-auto text-left text-sm">
            {transcriptions.map((t, i) => (
                <div key={i}>
                    {t.user && <p><strong className="text-blue-600">You:</strong> {t.user}</p>}
                    {t.model && <p><strong className="text-green-600">AI:</strong> {t.model}</p>}
                </div>
            ))}
             <div>
                {currentTranscription.user && <p><strong className="text-blue-600">You:</strong> {currentTranscription.user}</p>}
                {currentTranscription.model && <p><strong className="text-green-600">AI:</strong> {currentTranscription.model}</p>}
            </div>
        </div>

      </div>

      <div className="h-16"></div>
    </div>
  );
};

export default HomePage;