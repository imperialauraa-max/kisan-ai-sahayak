import React, { useState, useMemo } from 'react';
import { MandiPrice, Language } from '../types';
import { MOCK_MANDI_PRICES, I18N, LANGUAGES } from '../constants';

interface PricesPageProps {
  language: Language;
}

const PricesPage: React.FC<PricesPageProps> = ({ language }) => {
  const t = I18N[language];
  const [searchTerm, setSearchTerm] = useState('');
  const [prices] = useState<MandiPrice[]>(MOCK_MANDI_PRICES);

  const filteredPrices = useMemo(() => {
    return prices.filter(price =>
      price.commodity.toLowerCase().includes(searchTerm.toLowerCase()) ||
      price.market.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [prices, searchTerm]);

  return (
    <div className="p-4 bg-lime-50 min-h-full">
      <div className="mb-4">
        <input
          type="text"
          placeholder={t.searchCommodity}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-3 border border-green-300 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:outline-none"
        />
      </div>

      <div className="overflow-x-auto bg-white rounded-lg shadow-md">
        <table className="min-w-full text-sm text-left text-gray-700">
          <thead className="bg-green-600 text-white uppercase text-xs">
            <tr>
              <th scope="col" className="px-4 py-3">{t.commodity}</th>
              <th scope="col" className="px-4 py-3">{t.market}</th>
              <th scope="col" className="px-4 py-3 text-right">{t.minPrice}</th>
              <th scope="col" className="px-4 py-3 text-right">{t.maxPrice}</th>
              <th scope="col" className="px-4 py-3 text-right">{t.modalPrice}</th>
            </tr>
          </thead>
          <tbody>
            {filteredPrices.map((price, index) => (
              <tr key={price.id} className={`border-b ${index % 2 === 0 ? 'bg-white' : 'bg-green-50/50'}`}>
                <td className="px-4 py-3 font-medium text-green-900 whitespace-nowrap">{price.commodity}</td>
                <td className="px-4 py-3">{price.market}</td>
                <td className="px-4 py-3 text-right">₹{price.minPrice}</td>
                <td className="px-4 py-3 text-right">₹{price.maxPrice}</td>
                <td className="px-4 py-3 font-bold text-right">₹{price.modalPrice}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
       {filteredPrices.length === 0 && <p className="text-center mt-8 text-gray-500">No matching prices found.</p>}
    </div>
  );
};

export default PricesPage;