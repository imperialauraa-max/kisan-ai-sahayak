
import React, { useState } from 'react';
import { Language } from '../types';
import { I18N, LANGUAGES } from '../constants';

interface ProfilePageProps {
  language: Language;
  setLanguage: (language: Language) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ language, setLanguage }) => {
  const t = I18N[language];
  const [feedback, setFeedback] = useState('');

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (feedback.trim()) {
      alert(`Thank you for your feedback:\n\n"${feedback}"`);
      setFeedback('');
    }
  };

  return (
    <div className="p-4 bg-lime-50 min-h-full">
      <div className="max-w-md mx-auto">
        <div className="bg-white p-4 rounded-lg shadow-md mb-6">
          <h2 className="text-xl font-bold text-green-800 mb-3">{t.language}</h2>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as Language)}
            className="w-full p-3 border border-green-300 rounded-lg bg-white"
          >
            {LANGUAGES.map(lang => (
              <option key={lang} value={lang}>{lang}</option>
            ))}
          </select>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-md">
          <h2 className="text-xl font-bold text-green-800 mb-3">{t.feedback}</h2>
          <form onSubmit={handleFeedbackSubmit}>
            <textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder={t.yourFeedback}
              className="w-full p-2 border border-green-300 rounded-lg mb-3"
              rows={4}
            />
            <button
              type="submit"
              className="w-full bg-green-600 text-white p-3 rounded-lg font-bold hover:bg-green-700 disabled:bg-green-300"
            >
              {t.submit}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
