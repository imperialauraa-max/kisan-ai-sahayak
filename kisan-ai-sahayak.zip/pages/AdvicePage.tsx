import React, { useState, useRef, useEffect } from 'react';
import { getComplexAdvice, sendMessageToChat, startChat } from '../services/geminiService';
import { blobToBase64 } from '../utils/helpers';
import { I18N, LANGUAGES } from '../constants';
import { ChatMessage, Language } from '../types';

interface AdvicePageProps {
  language: Language;
}

const AdvicePage: React.FC<AdvicePageProps> = ({ language }) => {
  const t = I18N[language];
  const [adviceQuery, setAdviceQuery] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [adviceResult, setAdviceResult] = useState('');
  const [isGettingAdvice, setIsGettingAdvice] = useState(false);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatting, setIsChatting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    startChat(); // Initialize chat session when component mounts
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleGetAdvice = async () => {
    if (!adviceQuery) return;
    setIsGettingAdvice(true);
    setAdviceResult('');
    try {
      let imagePart;
      if (imageFile) {
        const base64Data = await blobToBase64(imageFile);
        imagePart = {
          inlineData: {
            data: base64Data,
            mimeType: imageFile.type,
          },
        };
      }
      const result = await getComplexAdvice(adviceQuery, imagePart);
      setAdviceResult(result);
    } catch (error) {
      console.error(error);
      setAdviceResult('An error occurred while getting advice.');
    } finally {
      setIsGettingAdvice(false);
    }
  };

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMessage: ChatMessage = { sender: 'user', text: chatInput };
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setIsChatting(true);

    const response = await sendMessageToChat(chatInput);
    const geminiMessage: ChatMessage = { sender: 'gemini', text: response };
    setChatMessages(prev => [...prev, geminiMessage]);
    setIsChatting(false);
  };

  return (
    <div className="p-4 bg-lime-50 min-h-full">
      {/* Complex Advice Section */}
      <div className="bg-white p-4 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-bold text-green-800 mb-3">{t.getAdvice}</h2>
        <textarea
          value={adviceQuery}
          onChange={(e) => setAdviceQuery(e.target.value)}
          placeholder={t.askQuestion}
          className="w-full p-2 border border-green-300 rounded-lg mb-3"
          rows={3}
        />
        <div className="flex items-center justify-between mb-3">
            <button onClick={() => fileInputRef.current?.click()} className="text-sm bg-gray-200 hover:bg-gray-300 text-gray-800 py-2 px-4 rounded-lg">
                {t.uploadImage}
            </button>
            <input type="file" ref={fileInputRef} onChange={handleImageChange} accept="image/*" className="hidden" />
            {imagePreview && <img src={imagePreview} alt="Crop preview" className="h-16 w-16 object-cover rounded-lg" />}
        </div>
        <button
          onClick={handleGetAdvice}
          disabled={isGettingAdvice}
          className="w-full bg-green-600 text-white p-3 rounded-lg font-bold hover:bg-green-700 disabled:bg-green-300"
        >
          {isGettingAdvice ? t.analyzing : t.submit}
        </button>
        {isGettingAdvice && <div className="w-full bg-green-100 h-2 rounded-full mt-2 overflow-hidden"><div className="bg-green-500 h-2 animate-pulse w-full"></div></div>}
        {adviceResult && <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200 whitespace-pre-wrap">{adviceResult}</div>}
      </div>

      {/* Chatbot Section */}
      <div className="bg-white p-4 rounded-lg shadow-md">
        <h2 className="text-xl font-bold text-green-800 mb-3">{t.chatWithAI}</h2>
        <div className="h-64 overflow-y-auto border border-green-200 rounded-lg p-3 mb-3 flex flex-col gap-2">
            {chatMessages.map((msg, index) => (
                <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xs md:max-w-md p-2 rounded-lg ${msg.sender === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}>
                        {msg.text}
                    </div>
                </div>
            ))}
            {isChatting && (
                 <div className="flex justify-start">
                    <div className="bg-gray-200 text-gray-800 p-2 rounded-lg">
                        <span className="animate-pulse">...</span>
                    </div>
                </div>
            )}
            <div ref={chatEndRef} />
        </div>
        <form onSubmit={handleChatSubmit} className="flex gap-2">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder={t.typeMessage}
            className="flex-grow p-2 border border-green-300 rounded-lg"
          />
          <button type="submit" className="bg-green-600 text-white px-4 rounded-lg font-bold hover:bg-green-700">Send</button>
        </form>
      </div>
    </div>
  );
};

export default AdvicePage;