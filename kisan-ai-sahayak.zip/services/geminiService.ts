
import { GoogleGenAI, Chat, GenerateContentResponse, Modality, LiveSession, LiveServerMessage } from "@google/genai";
import { ChatMessage } from "../types";

// Assume API_KEY is set in the environment.
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  // In a real app, you'd handle this more gracefully.
  console.error("API_KEY environment variable not set.");
}
const ai = new GoogleGenAI({ apiKey: API_KEY });

// For complex crop advice with deep analysis
export const getComplexAdvice = async (prompt: string, imagePart?: { inlineData: { data: string, mimeType: string } }): Promise<string> => {
  try {
    const contents = imagePart ? { parts: [ {text: prompt}, imagePart ]} : prompt;
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents,
      config: {
        thinkingConfig: { thinkingBudget: 32768 }
      }
    });
    return response.text;
  } catch (error) {
    console.error("Error getting complex advice:", error);
    return "Sorry, I couldn't get advice right now. Please try again.";
  }
};

// For the chatbot functionality
let chat: Chat | null = null;
export const startChat = () => {
  chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    history: [],
  });
};

export const sendMessageToChat = async (message: string): Promise<string> => {
  if (!chat) {
    startChat();
  }
  try {
    const response: GenerateContentResponse = await chat!.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Error sending chat message:", error);
    return "Sorry, I'm having trouble responding. Please try again.";
  }
};


// For real-time voice conversations
export const connectLive = (callbacks: {
    onopen: () => void;
    onmessage: (message: LiveServerMessage) => void;
    onerror: (e: ErrorEvent) => void;
    onclose: (e: CloseEvent) => void;
}): Promise<LiveSession> => {

    const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks,
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            systemInstruction: 'You are a friendly and helpful agricultural assistant for Indian farmers. Respond in a clear, simple, and encouraging tone. Keep answers concise.'
        }
    });

    return sessionPromise;
}
