
import React, { useState, useEffect } from 'react';
import { Page, Language } from './types';
import BottomNav from './components/BottomNav';
import HomePage from './pages/HomePage';
import WeatherPage from './pages/WeatherPage';
import PricesPage from './pages/PricesPage';
import AdvicePage from './pages/AdvicePage';
import ProfilePage from './pages/ProfilePage';
import { I18N, LANGUAGES } from './constants';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.Home);
  const [language, setLanguage] = useState<Language>(Language.en);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showOfflineToast, setShowOfflineToast] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => {
        setIsOnline(true);
        setShowOfflineToast(false);
    };
    const handleOffline = () => {
        setIsOnline(false);
        setShowOfflineToast(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    if(!isOnline) {
      setTimeout(() => setShowOfflineToast(false), 5000);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [isOnline]);

  const renderPage = () => {
    switch (currentPage) {
      case Page.Home:
        return <HomePage language={language} />;
      case Page.Weather:
        return <WeatherPage language={language} />;
      case Page.Prices:
        return <PricesPage language={language} />;
      case Page.Advice:
        return <AdvicePage language={language} />;
      case Page.Profile:
        return <ProfilePage language={language} setLanguage={setLanguage} />;
      default:
        return <HomePage language={language} />;
    }
  };

  const t = I18N[language];

  return (
    <div className="h-screen w-screen flex flex-col font-sans bg-lime-50">
      {showOfflineToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-yellow-500 text-white px-4 py-2 rounded-full shadow-lg z-50 animate-bounce">
            {t.offline}
        </div>
      )}
      <header className="bg-green-600 text-white shadow-md p-4 text-center z-10">
        <h1 className="text-2xl font-bold">Kisan AI Sahayak</h1>
      </header>
      <main className="flex-grow overflow-y-auto pb-20">
        {renderPage()}
      </main>
      <BottomNav currentPage={currentPage} setCurrentPage={setCurrentPage} language={language} />
    </div>
  );
};

export default App;
