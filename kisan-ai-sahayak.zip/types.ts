
export enum Page {
  Home = 'Home',
  Weather = 'Weather',
  Prices = 'Prices',
  Advice = 'Advice',
  Profile = 'Profile',
}

export enum Language {
  en = 'English',
  hi = 'हिन्दी',
  mr = 'मराठी',
  gu = 'ગુજરાતી',
}

export interface WeatherData {
  city: string;
  temperature: number;
  condition: string;
  icon: string;
  humidity: number;
  windSpeed: number;
}

export interface ForecastData {
  day: string;
  temp_max: number;
  temp_min: number;
  condition: string;
  icon: string;
}

export interface MandiPrice {
  id: number;
  commodity: string;
  market: string;
  minPrice: number;
  maxPrice: number;
  modalPrice: number;
}

export interface ChatMessage {
  sender: 'user' | 'gemini';
  text: string;
}
